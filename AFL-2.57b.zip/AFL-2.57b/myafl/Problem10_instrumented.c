/* AFL Instrumentation begin */
unsigned int __afl_cur_loc;
extern unsigned char*__afl_area_ptr;
/* AFL Instrumentation end */
extern char __VERIFUZZ_nondet_char() ;
extern unsigned char __VERIFUZZ_nondet_uchar();
extern short __VERIFUZZ_nondet_short();
extern unsigned short__VERIFUZZ_nondet_ushort();
extern int __VERIFUZZ_nondet_int();
extern unsigned int __VERIFUZZ_nondet_uint();
extern long __VERIFUZZ_nondet_long();
extern unsigned long __VERIFUZZ_nondet_ulong();
extern float __VERIFUZZ_nondet_float();
extern double __VERIFUZZ_nondet_double();
extern _Bool __VERIFUZZ_nondet_bool();
extern void* __VERIFUZZ_nondet_pointer();

extern int  __VERIFIER_nondet_int();
extern void  __assert_fail(char  const* __assertion, char  const* __file, unsigned int  __line, char  const* __function);
extern void  __assert_perror_fail(int  __errnum, char  const* __file, unsigned int  __line, char  const* __function);
extern void  __assert(char  const* __assertion, char  const* __file, int  __line);
void  reach_error();
void  reach_error_b();
void  reach_error_a();
void  reach_error_0();
void  reach_error_1();
void  reach_error_2();
void  reach_error_3();
void  reach_error_4();
void  reach_error_5();
void  reach_error_6();
void  reach_error_7();
void  reach_error_8();
void  reach_error_9();
void  reach_error_10();
void  reach_error_11();
void  reach_error_12();
void  reach_error_13();
void  reach_error_14();
void  reach_error_15();
void  reach_error_16();
void  reach_error_17();
void  reach_error_18();
void  reach_error_19();
void  reach_error_20();
void  reach_error_21();
void  reach_error_22();
void  reach_error_23();
void  reach_error_24();
void  reach_error_25();
void  reach_error_26();
void  reach_error_27();
void  reach_error_28();
void  reach_error_29();
void  reach_error_30();
void  reach_error_31();
void  reach_error_32();
void  reach_error_33();
void  reach_error_34();
void  reach_error_35();
void  reach_error_36();
void  reach_error_37();
void  reach_error_38();
void  reach_error_39();
void  reach_error_40();
void  reach_error_41();
void  reach_error_42();
void  reach_error_43();
void  reach_error_44();
void  reach_error_45();
void  reach_error_46();
void  reach_error_47();
void  reach_error_48();
void  reach_error_49();
void  reach_error_50();
void  reach_error_51();
void  reach_error_52();
void  reach_error_53();
void  reach_error_54();
void  reach_error_55();
void  reach_error_56();
void  reach_error_57();
void  reach_error_58();
void  reach_error_59();
void  reach_error_60();
void  reach_error_61();
void  reach_error_62();
void  reach_error_63();
void  reach_error_64();
void  reach_error_65();
void  reach_error_66();
void  reach_error_67();
void  reach_error_68();
void  reach_error_69();
void  reach_error_70();
void  reach_error_71();
void  reach_error_72();
void  reach_error_73();
void  reach_error_74();
void  reach_error_75();
void  reach_error_76();
void  reach_error_77();
void  reach_error_78();
void  reach_error_79();
void  reach_error_80();
void  reach_error_81();
void  reach_error_82();
void  reach_error_83();
void  reach_error_84();
void  reach_error_85();
void  reach_error_86();
void  reach_error_87();
void  reach_error_88();
void  reach_error_89();
void  reach_error_90();
void  reach_error_91();
void  reach_error_92();
void  reach_error_93();
void  reach_error_94();
void  reach_error_95();
void  reach_error_96();
void  reach_error_97();
void  reach_error_98();
void  reach_error_99();
extern void  errorCheck();
void  errorCheck();
extern void  calculate_output(int  );
void  calculate_output(int  input);
void  calculate_outputm1(int  input);
void  calculate_outputm37(int  input);
void  calculate_outputm2(int  input);
void  calculate_outputm41(int  input);
void  calculate_outputm5(int  input);
void  calculate_outputm58(int  input);
void  calculate_outputm59(int  input);
void  calculate_outputm7(int  input);
void  calculate_outputm65(int  input);
void  calculate_outputm8(int  input);
void  calculate_outputm69(int  input);
void  calculate_outputm71(int  input);
void  calculate_outputm11(int  input);
void  calculate_outputm77(int  input);
void  calculate_outputm79(int  input);
void  calculate_outputm12(int  input);
void  calculate_outputm81(int  input);
void  calculate_outputm13(int  input);
void  calculate_outputm85(int  input);
void  calculate_outputm16(int  input);
void  calculate_outputm95(int  input);
void  calculate_outputm17(int  input);
void  calculate_outputm96(int  input);
void  calculate_outputm97(int  input);
void  calculate_outputm22(int  input);
void  calculate_outputm113(int  input);
void  calculate_outputm23(int  input);
void  calculate_outputm119(int  input);
void  calculate_outputm120(int  input);
void  calculate_outputm27(int  input);
void  calculate_outputm129(int  input);
void  calculate_outputm28(int  input);
void  calculate_outputm131(int  input);
void  calculate_outputm137(int  input);
void  calculate_outputm29(int  input);
void  calculate_outputm139(int  input);
void  calculate_outputm30(int  input);
void  calculate_outputm145(int  input);
void  calculate_outputm32(int  input);
void  calculate_outputm152(int  input);
extern void  calculate_outputm1(int  );
extern void  calculate_outputm2(int  );
extern void  calculate_outputm3(int  );
extern void  calculate_outputm4(int  );
extern void  calculate_outputm5(int  );
extern void  calculate_outputm6(int  );
extern void  calculate_outputm7(int  );
extern void  calculate_outputm8(int  );
extern void  calculate_outputm9(int  );
extern void  calculate_outputm10(int  );
extern void  calculate_outputm11(int  );
extern void  calculate_outputm12(int  );
extern void  calculate_outputm13(int  );
extern void  calculate_outputm14(int  );
extern void  calculate_outputm15(int  );
extern void  calculate_outputm16(int  );
extern void  calculate_outputm17(int  );
extern void  calculate_outputm18(int  );
extern void  calculate_outputm19(int  );
extern void  calculate_outputm20(int  );
extern void  calculate_outputm21(int  );
extern void  calculate_outputm22(int  );
extern void  calculate_outputm23(int  );
extern void  calculate_outputm24(int  );
extern void  calculate_outputm25(int  );
extern void  calculate_outputm26(int  );
extern void  calculate_outputm27(int  );
extern void  calculate_outputm28(int  );
extern void  calculate_outputm29(int  );
extern void  calculate_outputm30(int  );
extern void  calculate_outputm31(int  );
extern void  calculate_outputm32(int  );
extern void  calculate_outputm33(int  );
extern void  calculate_outputm34(int  );
extern void  calculate_outputm35(int  );
extern void  calculate_outputm36(int  );
extern void  calculate_outputm37(int  );
extern void  calculate_outputm38(int  );
extern void  calculate_outputm39(int  );
extern void  calculate_outputm40(int  );
extern void  calculate_outputm41(int  );
extern void  calculate_outputm42(int  );
extern void  calculate_outputm43(int  );
extern void  calculate_outputm44(int  );
extern void  calculate_outputm45(int  );
extern void  calculate_outputm46(int  );
extern void  calculate_outputm47(int  );
extern void  calculate_outputm48(int  );
extern void  calculate_outputm49(int  );
extern void  calculate_outputm50(int  );
extern void  calculate_outputm51(int  );
extern void  calculate_outputm52(int  );
extern void  calculate_outputm53(int  );
extern void  calculate_outputm54(int  );
extern void  calculate_outputm55(int  );
extern void  calculate_outputm56(int  );
extern void  calculate_outputm57(int  );
extern void  calculate_outputm58(int  );
extern void  calculate_outputm59(int  );
extern void  calculate_outputm60(int  );
extern void  calculate_outputm61(int  );
extern void  calculate_outputm62(int  );
extern void  calculate_outputm63(int  );
extern void  calculate_outputm64(int  );
extern void  calculate_outputm65(int  );
extern void  calculate_outputm66(int  );
extern void  calculate_outputm67(int  );
extern void  calculate_outputm68(int  );
extern void  calculate_outputm69(int  );
extern void  calculate_outputm70(int  );
extern void  calculate_outputm71(int  );
extern void  calculate_outputm72(int  );
extern void  calculate_outputm73(int  );
extern void  calculate_outputm74(int  );
extern void  calculate_outputm75(int  );
extern void  calculate_outputm76(int  );
extern void  calculate_outputm77(int  );
extern void  calculate_outputm78(int  );
extern void  calculate_outputm79(int  );
extern void  calculate_outputm80(int  );
extern void  calculate_outputm81(int  );
extern void  calculate_outputm82(int  );
extern void  calculate_outputm83(int  );
extern void  calculate_outputm84(int  );
extern void  calculate_outputm85(int  );
extern void  calculate_outputm86(int  );
extern void  calculate_outputm87(int  );
extern void  calculate_outputm88(int  );
extern void  calculate_outputm89(int  );
extern void  calculate_outputm90(int  );
extern void  calculate_outputm91(int  );
extern void  calculate_outputm92(int  );
extern void  calculate_outputm93(int  );
extern void  calculate_outputm94(int  );
extern void  calculate_outputm95(int  );
extern void  calculate_outputm96(int  );
extern void  calculate_outputm97(int  );
extern void  calculate_outputm98(int  );
extern void  calculate_outputm99(int  );
extern void  calculate_outputm100(int  );
extern void  calculate_outputm101(int  );
extern void  calculate_outputm102(int  );
extern void  calculate_outputm103(int  );
extern void  calculate_outputm104(int  );
extern void  calculate_outputm105(int  );
extern void  calculate_outputm106(int  );
extern void  calculate_outputm107(int  );
extern void  calculate_outputm108(int  );
extern void  calculate_outputm109(int  );
extern void  calculate_outputm110(int  );
extern void  calculate_outputm111(int  );
extern void  calculate_outputm112(int  );
extern void  calculate_outputm113(int  );
extern void  calculate_outputm114(int  );
extern void  calculate_outputm115(int  );
extern void  calculate_outputm116(int  );
extern void  calculate_outputm117(int  );
extern void  calculate_outputm118(int  );
extern void  calculate_outputm119(int  );
extern void  calculate_outputm120(int  );
extern void  calculate_outputm121(int  );
extern void  calculate_outputm122(int  );
extern void  calculate_outputm123(int  );
extern void  calculate_outputm124(int  );
extern void  calculate_outputm125(int  );
extern void  calculate_outputm126(int  );
extern void  calculate_outputm127(int  );
extern void  calculate_outputm128(int  );
extern void  calculate_outputm129(int  );
extern void  calculate_outputm130(int  );
extern void  calculate_outputm131(int  );
extern void  calculate_outputm132(int  );
extern void  calculate_outputm133(int  );
extern void  calculate_outputm134(int  );
extern void  calculate_outputm135(int  );
extern void  calculate_outputm136(int  );
extern void  calculate_outputm137(int  );
extern void  calculate_outputm138(int  );
extern void  calculate_outputm139(int  );
extern void  calculate_outputm140(int  );
extern void  calculate_outputm141(int  );
extern void  calculate_outputm142(int  );
extern void  calculate_outputm143(int  );
extern void  calculate_outputm144(int  );
extern void  calculate_outputm145(int  );
extern void  calculate_outputm146(int  );
extern void  calculate_outputm147(int  );
extern void  calculate_outputm148(int  );
extern void  calculate_outputm149(int  );
extern void  calculate_outputm150(int  );
extern void  calculate_outputm151(int  );
extern void  calculate_outputm152(int  );
extern void  calculate_outputm153(int  );
extern void  calculate_outputm154(int  );
extern void  calculate_outputm155(int  );
extern void  calculate_outputm156(int  );
extern void  calculate_outputm157(int  );
int  main();
int  inputs [5]={5, 1, 3, 2, 4};
int  a1554992028=8;
int  a1933271548=9;
int  a1551570219=32;
int  cf=1;
int  a1649592707=34;
int  a469914660=14;
int  a1868984816=12;
int  a1041640432=10;
int  a2077863541=14;
int  a1591641889=11;
int  a1384943560=34;
int  a1669722568=32;
int  a1944816302=32;
int  a43901077=33;
int  a1136264456=35;
int  a1583922005=6;
int  a1431178715=32;
int  a927814483=8;
int  a1450658394=9;
int  a231305105=13;
int  a1491567675=16;
int  a938827910=33;
int  a1796618233=33;
int  a1379546326=7;
int  a2108703896=36;
int  a843079661=35;
int  a1580663338=33;
int  a1294378386=8;
int  a181636438=33;
int  a510889416=36;

void  reach_error()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 3393;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	__assert_fail("", "", 0, "");
	}
	}
void  reach_error_b()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 43155;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error();
	}
	}
void  reach_error_a()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 51377;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error();
	}
	}
void  reach_error_0()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 44153;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_1()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 30861;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_2()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 46015;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_3()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 31638;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_4()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 61975;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_5()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 43567;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_6()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 49681;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_7()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 39302;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_8()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 13642;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_9()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 24066;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_10()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 20842;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_11()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 6617;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_12()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 61203;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_13()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 63625;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_14()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 38119;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_15()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 12289;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_16()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 47756;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_17()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 11743;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_18()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 50214;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_19()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 6348;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_20()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 382;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_21()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 37334;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_22()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 22192;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_23()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 49344;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_24()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 49517;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_25()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 46745;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_26()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 700;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_27()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 50929;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_28()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 18295;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_29()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 18390;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_30()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 38107;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_31()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 50993;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_32()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 25079;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_33()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 64972;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_34()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 49201;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_35()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 6305;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_36()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 35458;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_37()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 35013;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_38()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 22375;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_39()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 60003;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_40()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 11485;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_41()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 56514;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_42()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 10865;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_43()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 61118;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_44()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 7470;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_45()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 4912;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_46()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 26168;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_47()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 57595;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_48()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 32703;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_49()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 8533;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_50()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 39311;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_51()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 7848;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_52()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 65452;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_53()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 13596;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_54()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 41773;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_55()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 16920;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_56()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 60181;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_57()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 59828;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_58()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 13559;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_59()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 36592;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_60()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 18280;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_61()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 52235;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_62()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 55317;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_63()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 14733;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_64()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 40549;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_65()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 41492;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_66()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 32561;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_67()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 60754;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_68()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 17691;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_69()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 32880;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_70()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 41525;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_71()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 19125;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_72()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 56287;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_73()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 50573;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_74()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 16750;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_75()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 6738;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_76()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 24468;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_77()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 18518;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_78()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 51818;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_79()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 44199;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_80()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 15753;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_81()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 52176;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_82()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 62267;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_83()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 28470;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_84()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 36887;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_85()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 39650;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_86()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 56147;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_87()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 22425;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_88()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 39648;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_89()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 14;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_90()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 31551;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_91()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 29787;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_92()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 57441;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_b();
	}
	}
void  reach_error_93()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 26489;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_94()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 9261;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_95()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 4989;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_96()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 7969;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_97()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 23797;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_98()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 319;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  reach_error_99()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 31833;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	reach_error_a();
	}
	}
void  errorCheck()
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 47418;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((a1554992028 == 9 && a1933271548 == 3) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 55373;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_0();
	}
	}
	if(((a1649592707 == 35 && a1933271548 == 5) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 4522;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_1();
	}
	}
	if(((a469914660 == 8 && a1868984816 == 8) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 15402;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_2();
	}
	}
	if(((a1554992028 == 12 && a1041640432 == 4) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 7285;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_3();
	}
	}
	if(((a2077863541 == 11 && a1868984816 == 10) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 30040;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_4();
	}
	}
	if(((a1591641889 == 9 && a1933271548 == 8) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 33241;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_5();
	}
	}
	if(((a1384943560 == 33 && a1669722568 == 35) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 25492;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_6();
	}
	}
	if(((a1554992028 == 15 && a1933271548 == 3) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 47856;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_7();
	}
	}
	if(((a1554992028 == 11 && a1669722568 == 33) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 43633;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_8();
	}
	}
	if(((a1944816302 == 35 && a43901077 == 33) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 56142;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_9();
	}
	}
	if(((a1136264456 == 36 && a1041640432 == 5) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 32651;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_10();
	}
	}
	if(((a1384943560 == 35 && a1669722568 == 35) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 57871;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_11();
	}
	}
	if(((a1583922005 == 7 && a1669722568 == 32) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 26589;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_12();
	}
	}
	if(((a1583922005 == 9 && a1669722568 == 32) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 59472;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_13();
	}
	}
	if(((a469914660 == 7 && a1868984816 == 8) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 26872;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_14();
	}
	}
	if(((a1136264456 == 35 && a1041640432 == 8) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 49319;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_15();
	}
	}
	if(((a2077863541 == 14 && a1868984816 == 10) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 61864;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_16();
	}
	}
	if(((a1583922005 == 12 && a1669722568 == 32) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 62976;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_17();
	}
	}
	if(((a1591641889 == 5 && a1868984816 == 9) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 38786;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_18();
	}
	}
	if(((a1583922005 == 11 && a1669722568 == 32) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 53155;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_19();
	}
	}
	if(((a1591641889 == 6 && a1933271548 == 8) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 57351;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_20();
	}
	}
	if(((a1431178715 == 32 && a1041640432 == 9) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 8730;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_21();
	}
	}
	if(((a1933271548 == 3 && a1669722568 == 34) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 47166;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_22();
	}
	}
	if(((a927814483 == 9 && a43901077 == 35) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 37323;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_23();
	}
	}
	if(((a1384943560 == 34 && a1669722568 == 35) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 63668;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_24();
	}
	}
	if(((a1583922005 == 5 && a1669722568 == 32) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 35436;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_25();
	}
	}
	if(((a1554992028 == 13 && a1669722568 == 33) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 26675;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_26();
	}
	}
	if(((a1136264456 == 32 && a1041640432 == 8) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 4424;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_27();
	}
	}
	if(((a1944816302 == 35 && a1041640432 == 10) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 46596;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_28();
	}
	}
	if(((a1591641889 == 8 && a1868984816 == 9) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 60578;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_29();
	}
	}
	if(((a1554992028 == 10 && a1933271548 == 3) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 19319;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_30();
	}
	}
	if(((a1450658394 == 9 && a1669722568 == 36) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 41925;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_31();
	}
	}
	if(((a1933271548 == 4 && a1669722568 == 34) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 5047;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_32();
	}
	}
	if(((a1933271548 == 8 && a1669722568 == 34) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 22401;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_33();
	}
	}
	if(((a231305105 == 12 && a1868984816 == 15) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 33116;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_34();
	}
	}
	if(((a1491567675 == 16 && a43901077 == 34) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 23676;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_35();
	}
	}
	if(((a2077863541 == 13 && a1868984816 == 10) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 55783;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_36();
	}
	}
	if(((a43901077 == 34 && a1041640432 == 7) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 33983;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_37();
	}
	}
	if(((a1649592707 == 32 && a1041640432 == 11) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 50359;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_38();
	}
	}
	if(((a1491567675 == 11 && a43901077 == 34) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 43364;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_39();
	}
	}
	if(((a927814483 == 8 && a1933271548 == 9) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 11060;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_40();
	}
	}
	if(((a1554992028 == 10 && a1041640432 == 4) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 61272;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_41();
	}
	}
	if(((a927814483 == 13 && a1868984816 == 11) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 16481;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_42();
	}
	}
	if(((a1554992028 == 12 && a1933271548 == 10) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 44811;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_43();
	}
	}
	if(((a927814483 == 13 && a43901077 == 35) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 57048;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_44();
	}
	}
	if(((a1944816302 == 33 && a1041640432 == 10) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 25537;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_45();
	}
	}
	if(((a938827910 == 35 && a1868984816 == 12) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 18089;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_46();
	}
	}
	if(((a1649592707 == 32 && a1933271548 == 5) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 33793;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_47();
	}
	}
	if(((a1591641889 == 9 && a1868984816 == 9) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 34007;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_48();
	}
	}
	if(((a1796618233 == 33 && a1868984816 == 13) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 7918;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_49();
	}
	}
	if(((a1554992028 == 11 && a1041640432 == 4) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 48620;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_50();
	}
	}
	if(((a1136264456 == 36 && a1041640432 == 8) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 63013;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_51();
	}
	}
	if(((a1554992028 == 13 && a1933271548 == 10) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 11595;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_52();
	}
	}
	if(((a43901077 == 35 && a1041640432 == 7) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 21904;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_53();
	}
	}
	if(((a1649592707 == 35 && a1041640432 == 11) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 42287;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_54();
	}
	}
	if(((a1491567675 == 12 && a43901077 == 34) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 32018;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_55();
	}
	}
	if(((a1591641889 == 10 && a1933271548 == 8) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 22294;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_56();
	}
	}
	if(((a927814483 == 11 && a1933271548 == 9) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 36375;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_57();
	}
	}
	if(((a1933271548 == 9 && a1669722568 == 34) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 18957;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_58();
	}
	}
	if(((a927814483 == 10 && a1933271548 == 9) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 9233;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_59();
	}
	}
	if(((a1944816302 == 34 && a1041640432 == 10) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 9151;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_60();
	}
	}
	if(((a1379546326 == 11 && a1041640432 == 6) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 28516;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_61();
	}
	}
	if(((a2077863541 == 8 && a1868984816 == 10) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 1586;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_62();
	}
	}
	if(((a938827910 == 34 && a1868984816 == 12) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 32322;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_63();
	}
	}
	if(((a469914660 == 14 && a1868984816 == 8) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 2857;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_64();
	}
	}
	if(((a2108703896 == 33 && a1933271548 == 4) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 49245;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_65();
	}
	}
	if(((a843079661 == 33 && a43901077 == 36) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 65063;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_66();
	}
	}
	if(((a1379546326 == 9 && a1041640432 == 6) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 39107;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_67();
	}
	}
	if(((a927814483 == 12 && a1868984816 == 11) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 47090;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_68();
	}
	}
	if(((a927814483 == 9 && a1933271548 == 9) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 18049;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_69();
	}
	}
	if(((a1796618233 == 36 && a1868984816 == 13) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 46092;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_70();
	}
	}
	if(((a1384943560 == 36 && a1669722568 == 35) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 18588;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_71();
	}
	}
	if(((a1554992028 == 15 && a1041640432 == 4) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 12750;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_72();
	}
	}
	if(((a1379546326 == 8 && a1041640432 == 6) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 37874;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_73();
	}
	}
	if(((a1933271548 == 7 && a1669722568 == 34) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 56470;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_74();
	}
	}
	if(((a231305105 == 13 && a1868984816 == 15) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 22942;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_75();
	}
	}
	if(((a1591641889 == 11 && a1933271548 == 8) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 632;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_76();
	}
	}
	if(((a1384943560 == 32 && a1669722568 == 35) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 14837;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_77();
	}
	}
	if(((a1554992028 == 8 && a1933271548 == 3) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 64135;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_78();
	}
	}
	if(((a1554992028 == 9 && a1041640432 == 4) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 62025;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_79();
	}
	}
	if(((a1591641889 == 7 && a1868984816 == 9) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 40109;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_80();
	}
	}
	if(((a1554992028 == 11 && a1933271548 == 10) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 11929;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_81();
	}
	}
	if(((a1591641889 == 6 && a1868984816 == 9) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 4574;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_82();
	}
	}
	if(((a938827910 == 36 && a1868984816 == 12) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 59880;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_83();
	}
	}
	if(((a1580663338 == 32 && a1868984816 == 14) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 396;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_84();
	}
	}
	if(((a1450658394 == 10 && a1669722568 == 36) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 45732;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_85();
	}
	}
	if(((a938827910 == 33 && a1868984816 == 12) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 26825;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_86();
	}
	}
	if(((a1554992028 == 10 && a1933271548 == 10) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 46461;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_87();
	}
	}
	if(((a1933271548 == 5 && a1669722568 == 34) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 51119;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_88();
	}
	}
	if(((a1294378386 == 8 && a43901077 == 32) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 62994;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_89();
	}
	}
	if(((a1450658394 == 8 && a1669722568 == 36) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 46090;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_90();
	}
	}
	if(((a231305105 == 9 && a1868984816 == 15) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 42614;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_91();
	}
	}
	if(((a1554992028 == 8 && a1933271548 == 10) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 20442;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_92();
	}
	}
	if(((a1944816302 == 34 && a43901077 == 33) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 26763;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_93();
	}
	}
	if(((a1294378386 == 4 && a43901077 == 32) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 49607;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_94();
	}
	}
	if(((a2108703896 == 34 && a1933271548 == 4) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 22953;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_95();
	}
	}
	if(((a1796618233 == 32 && a1868984816 == 13) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 17122;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_96();
	}
	}
	if(((a927814483 == 13 && a1933271548 == 9) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 15251;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_97();
	}
	}
	if(((a1294378386 == 9 && a43901077 == 32) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 20812;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_98();
	}
	}
	if(((a181636438 == 35 && a1933271548 == 7) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 21418;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	reach_error_99();
	}
	}
	}
	}
void  calculate_outputm37(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 34510;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((((input == 5) && (a1551570219 == 33 && cf == 1)) && a1554992028 == 15) && a1669722568 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 1033;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1868984816 = 10;
	a1551570219 = 36;
	a2077863541 = 10;
	}
	}
	if(((a1551570219 == 33 && ((cf == 1 && a1669722568 == 33) && (input == 3))) && a1554992028 == 15))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 15962;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1669722568 = 32;
	a1583922005 = 10;
	}
	}
	if(((input == 1) && (a1554992028 == 15 && ((a1669722568 == 33 && cf == 1) && a1551570219 == 33))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 15205;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1669722568 = 36;
	a1450658394 = 12;
	}
	}
	}
	}
void  calculate_outputm1(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 7909;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((cf == 1 && a1554992028 == 15))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 42746;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm37(input);
	}
	}
	}
	}
void  calculate_outputm41(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 48750;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1669722568 == 32 && (a1583922005 == 10 && ((cf == 1 && (input == 4)) && a1551570219 == 33))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 5609;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 32;
	a1041640432 = 6;
	a1379546326 = 8;
	}
	}
	if((a1669722568 == 32 && ((input == 1) && (a1551570219 == 33 && (cf == 1 && a1583922005 == 10)))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 35811;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1669722568 = 33;
	a1554992028 = 15;
	}
	}
	if((a1669722568 == 32 && (((cf == 1 && a1551570219 == 33) && a1583922005 == 10) && (input == 5))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 54731;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	}
	}
	}
	}
void  calculate_outputm2(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 2876;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1583922005 == 10 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 11722;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm41(input);
	}
	}
	}
	}
void  calculate_outputm58(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 31581;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((a1669722568 == 36 && ((input == 5) && (a1450658394 == 12 && cf == 1))) && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 12770;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 32;
	a1136264456 = 32;
	a1041640432 = 8;
	}
	}
	if(((input == 3) && ((a1450658394 == 12 && (cf == 1 && a1551570219 == 33)) && a1669722568 == 36)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 58272;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	}
	}
	}
	}
void  calculate_outputm59(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 53655;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((a1551570219 == 33 && (a1450658394 == 14 && (cf == 1 && (input == 1)))) && a1669722568 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 6938;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a510889416 = 32;
	a1551570219 = 34;
	a1933271548 = 6;
	}
	}
	if((((a1669722568 == 36 && (a1450658394 == 14 && cf == 1)) && a1551570219 == 33) && (input == 5)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 57425;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 35;
	a43901077 = 33;
	a1944816302 = 32;
	}
	}
	}
	}
void  calculate_outputm5(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 40700;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1450658394 == 12 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 9112;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm58(input);
	}
	}
	if((cf == 1 && a1450658394 == 14))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 16396;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm59(input);
	}
	}
	}
	}
void  calculate_outputm65(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 40587;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((input == 5) && (a1136264456 == 33 && ((cf == 1 && a1041640432 == 5) && a1551570219 == 32))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 15532;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a43901077 = 33;
	a1551570219 = 35;
	a1944816302 = 32;
	}
	}
	if((a1136264456 == 33 && (((cf == 1 && (input == 1)) && a1041640432 == 5) && a1551570219 == 32)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 28800;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 33;
	a1669722568 = 36;
	a1450658394 = 12;
	}
	}
	}
	}
void  calculate_outputm7(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 33045;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1136264456 == 33 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 2302;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm65(input);
	}
	}
	}
	}
void  calculate_outputm69(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 41672;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1041640432 == 6 && (a1379546326 == 10 && ((a1551570219 == 32 && cf == 1) && (input == 1)))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 15487;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 35;
	a43901077 = 35;
	a927814483 = 9;
	}
	}
	if((a1379546326 == 10 && (((a1041640432 == 6 && cf == 1) && (input == 3)) && a1551570219 == 32)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 48847;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1431178715 = 34;
	a1041640432 = 9;
	}
	}
	if(((a1551570219 == 32 && ((input == 5) && (a1041640432 == 6 && cf == 1))) && a1379546326 == 10))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 21072;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	}
	}
	}
	}
void  calculate_outputm71(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 59314;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((((a1041640432 == 6 && cf == 1) && a1551570219 == 32) && (input == 3)) && a1379546326 == 12))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 50978;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 34;
	a1933271548 = 10;
	a1554992028 = 8;
	}
	}
	if((a1041640432 == 6 && (((a1379546326 == 12 && cf == 1) && (input == 1)) && a1551570219 == 32)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 8635;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a43901077 = 32;
	a1551570219 = 35;
	a1294378386 = 10;
	}
	}
	if(((((cf == 1 && (input == 5)) && a1379546326 == 12) && a1551570219 == 32) && a1041640432 == 6))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 65396;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1379546326 = 10;
	}
	}
	}
	}
void  calculate_outputm8(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 13009;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((cf == 1 && a1379546326 == 10))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 65187;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm69(input);
	}
	}
	if((a1379546326 == 12 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 65016;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm71(input);
	}
	}
	}
	}
void  calculate_outputm77(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 53252;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((((input == 4) && (a1551570219 == 32 && (cf == 1 && a1431178715 == 33))) && a1041640432 == 9))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 27823;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 34;
	a2108703896 = 33;
	a1933271548 = 4;
	}
	}
	if(((((cf == 1 && a1041640432 == 9) && (input == 3)) && a1431178715 == 33) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 19969;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 35;
	a43901077 = 32;
	a1294378386 = 11;
	}
	}
	}
	}
void  calculate_outputm79(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 41026;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((input == 2) && (a1551570219 == 32 && ((cf == 1 && a1041640432 == 9) && a1431178715 == 34))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 15681;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 33;
	a1669722568 = 34;
	a1933271548 = 9;
	}
	}
	if((a1431178715 == 34 && (a1551570219 == 32 && ((input == 3) && (cf == 1 && a1041640432 == 9)))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 45570;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1649592707 = 34;
	a1041640432 = 11;
	}
	}
	if((a1551570219 == 32 && ((input == 1) && (a1431178715 == 34 && (cf == 1 && a1041640432 == 9)))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 43689;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	}
	}
	if(((((cf == 1 && a1431178715 == 34) && a1551570219 == 32) && (input == 5)) && a1041640432 == 9))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 14328;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	}
	}
	}
	}
void  calculate_outputm11(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 16661;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1431178715 == 33 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 58599;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm77(input);
	}
	}
	if((a1431178715 == 34 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 5865;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm79(input);
	}
	}
	}
	}
void  calculate_outputm81(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 28664;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((((cf == 1 && a1944816302 == 32) && a1551570219 == 32) && (input == 5)) && a1041640432 == 10))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 52894;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1431178715 = 33;
	a1041640432 = 9;
	}
	}
	if((((input == 1) && ((cf == 1 && a1944816302 == 32) && a1041640432 == 10)) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 48087;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 36;
	a1868984816 = 8;
	a469914660 = 12;
	}
	}
	if(((a1551570219 == 32 && ((cf == 1 && a1944816302 == 32) && (input == 2))) && a1041640432 == 10))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 46673;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 35;
	a43901077 = 32;
	a1294378386 = 10;
	}
	}
	}
	}
void  calculate_outputm12(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 2470;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1944816302 == 32 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 53806;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm81(input);
	}
	}
	}
	}
void  calculate_outputm85(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 55284;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1041640432 == 11 && ((a1649592707 == 34 && (cf == 1 && (input == 5))) && a1551570219 == 32)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 60048;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1431178715 = 34;
	a1041640432 = 9;
	}
	}
	if((((a1649592707 == 34 && (a1041640432 == 11 && cf == 1)) && (input == 2)) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 43984;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 36;
	a1868984816 = 9;
	a1591641889 = 5;
	}
	}
	if(((a1041640432 == 11 && (a1649592707 == 34 && ((input == 1) && cf == 1))) && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 42009;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	}
	}
	}
	}
void  calculate_outputm13(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 50298;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((cf == 1 && a1649592707 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 37915;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm85(input);
	}
	}
	}
	}
void  calculate_outputm95(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 52871;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((a1649592707 == 36 && (((input == 3) && cf == 1) && a1551570219 == 34)) && a1933271548 == 5))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 18738;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1136264456 = 33;
	a1551570219 = 32;
	a1041640432 = 5;
	}
	}
	if((a1933271548 == 5 && (a1649592707 == 36 && ((input == 5) && (a1551570219 == 34 && cf == 1)))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 4721;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 35;
	a43901077 = 33;
	a1944816302 = 32;
	}
	}
	if((((a1649592707 == 36 && (a1551570219 == 34 && cf == 1)) && (input == 4)) && a1933271548 == 5))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 3709;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1649592707 = 32;
	a1551570219 = 32;
	a1041640432 = 11;
	}
	}
	if(((((cf == 1 && a1551570219 == 34) && a1933271548 == 5) && a1649592707 == 36) && (input == 1)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 60520;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 33;
	a1669722568 = 36;
	a1450658394 = 14;
	}
	}
	}
	}
void  calculate_outputm16(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 41086;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((cf == 1 && a1649592707 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 61950;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm95(input);
	}
	}
	}
	}
void  calculate_outputm96(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 9280;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((((a510889416 == 33 && cf == 1) && (input == 5)) && a1933271548 == 6) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 39158;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1669722568 = 36;
	a1551570219 = 33;
	a1450658394 = 12;
	}
	}
	if((a1551570219 == 34 && ((a1933271548 == 6 && ((input == 1) && cf == 1)) && a510889416 == 33)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 37781;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	}
	}
	if((((a510889416 == 33 && ((input == 3) && cf == 1)) && a1933271548 == 6) && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 17532;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 36;
	a1868984816 = 8;
	a469914660 = 12;
	}
	}
	}
	}
void  calculate_outputm97(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 6885;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1933271548 == 6 && ((input == 3) && ((cf == 1 && a510889416 == 32) && a1551570219 == 34))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 44414;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1649592707 = 36;
	a1933271548 = 5;
	}
	}
	if(((((a1933271548 == 6 && cf == 1) && a1551570219 == 34) && a510889416 == 32) && (input == 1)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 31369;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1669722568 = 36;
	a1551570219 = 33;
	a1450658394 = 14;
	}
	}
	if((a1551570219 == 34 && ((a1933271548 == 6 && ((input == 5) && cf == 1)) && a510889416 == 32)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 39562;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 35;
	a43901077 = 33;
	a1944816302 = 32;
	}
	}
	}
	}
void  calculate_outputm17(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 46721;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a510889416 == 33 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 26200;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm96(input);
	}
	}
	if((a510889416 == 32 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 6711;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm97(input);
	}
	}
	}
	}
void  calculate_outputm113(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 14822;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a43901077 == 33 && (a1551570219 == 35 && ((input == 1) && (a1944816302 == 32 && cf == 1)))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 6997;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	}
	}
	if(((a1551570219 == 35 && (((input == 4) && cf == 1) && a1944816302 == 32)) && a43901077 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 50523;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 33;
	a1669722568 = 34;
	a1933271548 = 5;
	}
	}
	if(((a1551570219 == 35 && ((cf == 1 && a43901077 == 33) && (input == 5))) && a1944816302 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 6057;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 34;
	a1649592707 = 36;
	a1933271548 = 5;
	}
	}
	}
	}
void  calculate_outputm22(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 18702;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((cf == 1 && a1944816302 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 16095;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm113(input);
	}
	}
	}
	}
void  calculate_outputm119(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 61443;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((((cf == 1 && a43901077 == 32) && a1294378386 == 10) && (input == 5)) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 16522;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1431178715 = 34;
	a1551570219 = 32;
	a1041640432 = 9;
	}
	}
	if((((a1294378386 == 10 && (cf == 1 && a1551570219 == 35)) && (input == 3)) && a43901077 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 28845;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1041640432 = 6;
	a1551570219 = 32;
	a1379546326 = 12;
	}
	}
	if((((a1294378386 == 10 && (a43901077 == 32 && cf == 1)) && (input == 2)) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 41111;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1669722568 = 35;
	a1551570219 = 33;
	a1384943560 = 33;
	}
	}
	}
	}
void  calculate_outputm120(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 42541;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((((a1294378386 == 11 && (cf == 1 && a43901077 == 32)) && (input == 3)) && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 16262;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1868984816 = 10;
	a1551570219 = 36;
	a2077863541 = 11;
	}
	}
	if((a1551570219 == 35 && (a1294378386 == 11 && (a43901077 == 32 && (cf == 1 && (input == 5))))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 30770;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1669722568 = 32;
	a1551570219 = 33;
	a1583922005 = 10;
	}
	}
	if((a1294378386 == 11 && ((a1551570219 == 35 && (a43901077 == 32 && cf == 1)) && (input == 1))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 20773;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 36;
	a1796618233 = 34;
	a1868984816 = 13;
	}
	}
	}
	}
void  calculate_outputm23(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 57003;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((cf == 1 && a1294378386 == 10))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 41769;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm119(input);
	}
	}
	if((cf == 1 && a1294378386 == 11))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 6551;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm120(input);
	}
	}
	}
	}
void  calculate_outputm129(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 50089;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((a1868984816 == 8 && ((cf == 1 && a469914660 == 12) && a1551570219 == 36)) && (input == 5)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 58666;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1868984816 = 9;
	a1591641889 = 4;
	}
	}
	if(((((cf == 1 && (input == 4)) && a469914660 == 12) && a1868984816 == 8) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 54249;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a469914660 = 14;
	}
	}
	if(((a1868984816 == 8 && ((input == 3) && (a1551570219 == 36 && cf == 1))) && a469914660 == 12))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 31995;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 35;
	a43901077 = 33;
	a1944816302 = 32;
	}
	}
	if((((a1868984816 == 8 && (a469914660 == 12 && cf == 1)) && (input == 1)) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 58928;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1669722568 = 36;
	a1551570219 = 33;
	a1450658394 = 12;
	}
	}
	}
	}
void  calculate_outputm27(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 14240;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a469914660 == 12 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 25177;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm129(input);
	}
	}
	}
	}
void  calculate_outputm131(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 23720;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((input == 2) && (a1868984816 == 9 && ((cf == 1 && a1551570219 == 36) && a1591641889 == 4))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 3705;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1669722568 = 36;
	a1551570219 = 33;
	a1450658394 = 9;
	}
	}
	if((a1551570219 == 36 && (((cf == 1 && a1868984816 == 9) && a1591641889 == 4) && (input == 5))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 9265;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1868984816 = 11;
	a927814483 = 14;
	}
	}
	if(((((cf == 1 && (input == 1)) && a1551570219 == 36) && a1868984816 == 9) && a1591641889 == 4))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 15193;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a510889416 = 33;
	a1551570219 = 34;
	a1933271548 = 6;
	}
	}
	}
	}
void  calculate_outputm137(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 64993;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((input == 1) && (((cf == 1 && a1868984816 == 9) && a1591641889 == 11) && a1551570219 == 36)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 21452;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 35;
	a43901077 = 33;
	a1944816302 = 32;
	}
	}
	if((a1868984816 == 9 && ((a1591641889 == 11 && (cf == 1 && (input == 3))) && a1551570219 == 36)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 9680;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	}
	}
	if((a1868984816 == 9 && ((a1591641889 == 11 && (a1551570219 == 36 && cf == 1)) && (input == 5))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 16362;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1796618233 = 34;
	a1868984816 = 13;
	}
	}
	}
	}
void  calculate_outputm28(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 17529;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1591641889 == 4 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 17948;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm131(input);
	}
	}
	if((cf == 1 && a1591641889 == 11))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 53966;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm137(input);
	}
	}
	}
	}
void  calculate_outputm139(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 2603;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if(((((cf == 1 && (input == 1)) && a1868984816 == 10) && a2077863541 == 10) && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 14181;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 33;
	a1669722568 = 32;
	a1583922005 = 10;
	}
	}
	if((((input == 3) && (a2077863541 == 10 && (cf == 1 && a1551570219 == 36))) && a1868984816 == 10))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 4279;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a43901077 = 32;
	a1551570219 = 35;
	a1294378386 = 11;
	}
	}
	}
	}
void  calculate_outputm29(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 16566;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a2077863541 == 10 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 22598;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm139(input);
	}
	}
	}
	}
void  calculate_outputm145(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 29433;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1868984816 == 11 && (a1551570219 == 36 && (((input == 3) && cf == 1) && a927814483 == 14))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 20114;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1868984816 = 9;
	a1591641889 = 4;
	}
	}
	}
	}
void  calculate_outputm30(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 47034;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a927814483 == 14 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 53709;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm145(input);
	}
	}
	}
	}
void  calculate_outputm152(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 3387;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1868984816 == 13 && (((input == 5) && (a1796618233 == 34 && cf == 1)) && a1551570219 == 36)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 38880;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1551570219 = 35;
	a43901077 = 33;
	a1944816302 = 32;
	}
	}
	if((a1551570219 == 36 && ((input == 2) && (a1796618233 == 34 && (cf == 1 && a1868984816 == 13)))))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 29169;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1933271548 = 9;
	a1551570219 = 34;
	a927814483 = 9;
	}
	}
	if(((input == 1) && (((a1551570219 == 36 && cf == 1) && a1796618233 == 34) && a1868984816 == 13)))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 6655;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 0;
	a1868984816 = 9;
	a1591641889 = 11;
	}
	}
	}
	}
void  calculate_outputm32(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 2056;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((cf == 1 && a1796618233 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 48742;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm152(input);
	}
	}
	}
	}
void  calculate_output(int  input)
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 3534;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	cf = 1;
	if((cf == 1 && a1551570219 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 28951;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1669722568 == 33 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 17282;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm1(input);
	}
	}
	if((a1669722568 == 32 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 3630;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm2(input);
	}
	}
	if((a1669722568 == 36 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 53624;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm5(input);
	}
	}
	}
	}
	if((cf == 1 && a1551570219 == 32))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 28835;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1041640432 == 5 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 24893;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm7(input);
	}
	}
	if((a1041640432 == 6 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 32256;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm8(input);
	}
	}
	if((cf == 1 && a1041640432 == 9))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 1256;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm11(input);
	}
	}
	if((a1041640432 == 10 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 18893;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm12(input);
	}
	}
	if((a1041640432 == 11 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 43790;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm13(input);
	}
	}
	}
	}
	if((cf == 1 && a1551570219 == 34))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 43267;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((cf == 1 && a1933271548 == 5))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 11334;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm16(input);
	}
	}
	if((a1933271548 == 6 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 65002;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm17(input);
	}
	}
	}
	}
	if((cf == 1 && a1551570219 == 35))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 52040;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((cf == 1 && a43901077 == 33))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 4259;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm22(input);
	}
	}
	if((a43901077 == 32 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 25279;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm23(input);
	}
	}
	}
	}
	if((cf == 1 && a1551570219 == 36))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 25471;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	if((a1868984816 == 8 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 16285;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm27(input);
	}
	}
	if((cf == 1 && a1868984816 == 9))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 32890;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm28(input);
	}
	}
	if((cf == 1 && a1868984816 == 10))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 53646;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm29(input);
	}
	}
	if((cf == 1 && a1868984816 == 11))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 52568;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm30(input);
	}
	}
	if((a1868984816 == 13 && cf == 1))
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 60634;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
	calculate_outputm32(input);
	}
	}
	}
	}
	errorCheck();
	}
	}
void initExternVar()
{

}
int  main()
	{
	{
/* AFL Instrumentation begin */
__afl_cur_loc = 64448;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
	{
initExternVar() ;
	{
	while(1)
	{
	{
	{
	int  input;
	input = __VERIFIER_nondet_int();
	if((input != 5) && (input != 1) && (input != 3) && (input != 2) && (input != 4))

{
/* AFL Instrumentation begin */
__afl_cur_loc = 50151;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */
return -2;
}
	calculate_output(input);
	}
	}/* AFL Instrumentation begin */
__afl_cur_loc = 26373;
__afl_area_ptr[__afl_cur_loc]++;
/* AFL Instrumentation end */

	}
	}
	}

	}	}


/*Function definition of called functions. For AFL executable*/

 void  calculate_outputm40(int   a0 )
{
return ; ;
}

 void  calculate_outputm44(int   a0 )
{
return ; ;
}

 void  calculate_outputm43(int   a0 )
{
return ; ;
}

 void  calculate_outputm42(int   a0 )
{
return ; ;
}

 void  calculate_outputm48(int   a0 )
{
return ; ;
}

 void  calculate_outputm47(int   a0 )
{
return ; ;
}

 void  calculate_outputm46(int   a0 )
{
return ; ;
}

 void  calculate_outputm157(int   a0 )
{
return ; ;
}

 void  calculate_outputm45(int   a0 )
{
return ; ;
}

 void  calculate_outputm49(int   a0 )
{
return ; ;
}

 void  calculate_outputm33(int   a0 )
{
return ; ;
}

 void  calculate_outputm31(int   a0 )
{
return ; ;
}

 void  calculate_outputm36(int   a0 )
{
return ; ;
}

 void  __assert(char  const* __assertion, char  const* __file, int  __line)
{
return ; ;
}

 void  calculate_outputm35(int   a0 )
{
return ; ;
}

 void  calculate_outputm34(int   a0 )
{
return ; ;
}

 void  calculate_outputm39(int   a0 )
{
return ; ;
}

 void  calculate_outputm38(int   a0 )
{
return ; ;
}

 void  calculate_outputm100(int   a0 )
{
return ; ;
}

 void  calculate_outputm101(int   a0 )
{
return ; ;
}

 void  calculate_outputm21(int   a0 )
{
return ; ;
}

 void  calculate_outputm20(int   a0 )
{
return ; ;
}

 void  calculate_outputm26(int   a0 )
{
return ; ;
}

 void  calculate_outputm25(int   a0 )
{
return ; ;
}

 void  calculate_outputm24(int   a0 )
{
return ; ;
}

 void  __assert_perror_fail(int  __errnum, char  const* __file, unsigned int  __line, char  const* __function)
{
return ; ;
}

 void  calculate_outputm91(int   a0 )
{
return ; ;
}

 void  calculate_outputm111(int   a0 )
{
return ; ;
}

 void  calculate_outputm90(int   a0 )
{
return ; ;
}

 void  calculate_outputm112(int   a0 )
{
return ; ;
}

 void  calculate_outputm110(int   a0 )
{
return ; ;
}

 void  calculate_outputm94(int   a0 )
{
return ; ;
}

 void  calculate_outputm93(int   a0 )
{
return ; ;
}

 void  calculate_outputm92(int   a0 )
{
return ; ;
}

 void  calculate_outputm99(int   a0 )
{
return ; ;
}

 void  calculate_outputm108(int   a0 )
{
return ; ;
}

 void  calculate_outputm10(int   a0 )
{
return ; ;
}

 void  calculate_outputm98(int   a0 )
{
return ; ;
}

 void  calculate_outputm109(int   a0 )
{
return ; ;
}

 void  calculate_outputm106(int   a0 )
{
return ; ;
}

 void  calculate_outputm107(int   a0 )
{
return ; ;
}

 void  calculate_outputm15(int   a0 )
{
return ; ;
}

 void  calculate_outputm104(int   a0 )
{
return ; ;
}

 void  calculate_outputm14(int   a0 )
{
return ; ;
}

 void  calculate_outputm105(int   a0 )
{
return ; ;
}

 void  calculate_outputm102(int   a0 )
{
return ; ;
}

 void  calculate_outputm103(int   a0 )
{
return ; ;
}

 void  calculate_outputm19(int   a0 )
{
return ; ;
}

 void  calculate_outputm18(int   a0 )
{
return ; ;
}

 void  calculate_outputm80(int   a0 )
{
return ; ;
}

 void  calculate_outputm122(int   a0 )
{
return ; ;
}

 void  calculate_outputm123(int   a0 )
{
return ; ;
}

 void  calculate_outputm121(int   a0 )
{
return ; ;
}

 void  calculate_outputm84(int   a0 )
{
return ; ;
}

 void  calculate_outputm83(int   a0 )
{
return ; ;
}

 void  calculate_outputm82(int   a0 )
{
return ; ;
}

 void  calculate_outputm88(int   a0 )
{
return ; ;
}

 void  calculate_outputm87(int   a0 )
{
return ; ;
}

 void  calculate_outputm86(int   a0 )
{
return ; ;
}

 void  calculate_outputm117(int   a0 )
{
return ; ;
}

 void  calculate_outputm118(int   a0 )
{
return ; ;
}

 void  calculate_outputm115(int   a0 )
{
return ; ;
}

 void  calculate_outputm116(int   a0 )
{
return ; ;
}

 void  calculate_outputm89(int   a0 )
{
return ; ;
}

 void  calculate_outputm114(int   a0 )
{
return ; ;
}

 void  calculate_outputm133(int   a0 )
{
return ; ;
}

 void  calculate_outputm134(int   a0 )
{
return ; ;
}

 void  calculate_outputm9(int   a0 )
{
return ; ;
}

 void  calculate_outputm132(int   a0 )
{
return ; ;
}

 void  calculate_outputm4(int   a0 )
{
return ; ;
}

 void  calculate_outputm73(int   a0 )
{
return ; ;
}

 void  calculate_outputm3(int   a0 )
{
return ; ;
}

 void  calculate_outputm72(int   a0 )
{
return ; ;
}

 void  calculate_outputm130(int   a0 )
{
return ; ;
}

 void  calculate_outputm6(int   a0 )
{
return ; ;
}

 void  calculate_outputm70(int   a0 )
{
return ; ;
}

 void  calculate_outputm76(int   a0 )
{
return ; ;
}

 void  calculate_outputm75(int   a0 )
{
return ; ;
}

 void  calculate_outputm128(int   a0 )
{
return ; ;
}

 void  calculate_outputm74(int   a0 )
{
return ; ;
}

 void  calculate_outputm126(int   a0 )
{
return ; ;
}

 void  calculate_outputm127(int   a0 )
{
return ; ;
}

 void  calculate_outputm124(int   a0 )
{
return ; ;
}

 void  calculate_outputm78(int   a0 )
{
return ; ;
}

 void  calculate_outputm125(int   a0 )
{
return ; ;
}

 void  calculate_outputm144(int   a0 )
{
return ; ;
}

 void  calculate_outputm142(int   a0 )
{
return ; ;
}

 void  calculate_outputm143(int   a0 )
{
return ; ;
}

 void  calculate_outputm62(int   a0 )
{
return ; ;
}

 void  calculate_outputm140(int   a0 )
{
return ; ;
}

 void  calculate_outputm61(int   a0 )
{
return ; ;
}

 void  calculate_outputm141(int   a0 )
{
return ; ;
}

 void  calculate_outputm60(int   a0 )
{
return ; ;
}

 void  calculate_outputm66(int   a0 )
{
return ; ;
}

 void  calculate_outputm64(int   a0 )
{
return ; ;
}

 void  calculate_outputm63(int   a0 )
{
return ; ;
}

 void  calculate_outputm138(int   a0 )
{
return ; ;
}

 void  calculate_outputm68(int   a0 )
{
return ; ;
}

 void  calculate_outputm135(int   a0 )
{
return ; ;
}

 void  calculate_outputm67(int   a0 )
{
return ; ;
}

 void  calculate_outputm136(int   a0 )
{
return ; ;
}

 void  calculate_outputm155(int   a0 )
{
return ; ;
}

 void  calculate_outputm156(int   a0 )
{
return ; ;
}

 void  calculate_outputm153(int   a0 )
{
return ; ;
}

 void  calculate_outputm154(int   a0 )
{
return ; ;
}

 void  calculate_outputm51(int   a0 )
{
return ; ;
}

 void  calculate_outputm151(int   a0 )
{
return ; ;
}

 void  calculate_outputm50(int   a0 )
{
return ; ;
}

 void  calculate_outputm150(int   a0 )
{
return ; ;
}

 void  calculate_outputm55(int   a0 )
{
return ; ;
}

 void  calculate_outputm54(int   a0 )
{
return ; ;
}

 void  calculate_outputm53(int   a0 )
{
return ; ;
}

 void  calculate_outputm52(int   a0 )
{
return ; ;
}

 void  calculate_outputm148(int   a0 )
{
return ; ;
}

 void  calculate_outputm149(int   a0 )
{
return ; ;
}

 void  calculate_outputm57(int   a0 )
{
return ; ;
}

 void  calculate_outputm146(int   a0 )
{
return ; ;
}

 void  calculate_outputm56(int   a0 )
{
return ; ;
}

 void  calculate_outputm147(int   a0 )
{
return ; ;
}

