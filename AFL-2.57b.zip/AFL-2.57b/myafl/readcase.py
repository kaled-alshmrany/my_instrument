#!/usr/bin/env python3
file_str ='./tt/crash_001'
file_str = './aflOutputDir/crashes/crash_001'
fin = open(file_str,'r',encoding='unicode_escape')
for i in range(2):
    #val = int.from_bytes(str.encode(fin.read(4)), byteorder='little')
    print(int.from_bytes(str.encode(fin.read(2)), byteorder='little'))
    #val = int.from_bytes(fin.read(4), byteorder='little')
    #print(val)
#print(fin.read(4))
#print(fin.read(4))
#print(fin.read(4))
#print(fin.read(4))
fin.close()