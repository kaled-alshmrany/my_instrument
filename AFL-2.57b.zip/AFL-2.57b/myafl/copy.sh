#!/bin/sh
rm -f /home/hosam/sdb1/AFL-2.57b/myafl/libFuSeBMC_FuzzerLib_32.a
rm -f /home/hosam/sdb1/AFL-2.57b/myafl/libFuSeBMC_FuzzerLib_64.a
cp /home/hosam/sdb1/FuSeBMC/FuSeBMC_FuzzerLib/libFuSeBMC_FuzzerLib_32.a /home/hosam/sdb1/AFL-2.57b/myafl/
cp /home/hosam/sdb1/FuSeBMC/FuSeBMC_FuzzerLib/libFuSeBMC_FuzzerLib_64.a /home/hosam/sdb1/AFL-2.57b/myafl/

